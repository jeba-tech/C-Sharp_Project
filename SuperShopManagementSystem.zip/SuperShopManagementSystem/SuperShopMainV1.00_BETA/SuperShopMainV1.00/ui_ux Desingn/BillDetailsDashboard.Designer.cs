﻿namespace SuperShopMainV1._00
{
    partial class BillDetailsDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BillDetailsDashboard));
            this.billdetailsDashboardPanel = new System.Windows.Forms.Panel();
            this.MngBIll = new System.Windows.Forms.Button();
            this.logoutbutton = new System.Windows.Forms.Button();
            this.Addcutomerbutton = new System.Windows.Forms.Button();
            this.SalesButton = new System.Windows.Forms.Button();
            this.billdetailsadmindashboarlogo = new System.Windows.Forms.PictureBox();
            this.billdetailsiid = new System.Windows.Forms.Panel();
            this.searchbill = new System.Windows.Forms.Button();
            this.billdetailtlabel = new System.Windows.Forms.Label();
            this.billdetailsidtexbox = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.billdetailsDashboardPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.billdetailsadmindashboarlogo)).BeginInit();
            this.billdetailsiid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // billdetailsDashboardPanel
            // 
            this.billdetailsDashboardPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(20)))), ((int)(((byte)(22)))));
            this.billdetailsDashboardPanel.Controls.Add(this.MngBIll);
            this.billdetailsDashboardPanel.Controls.Add(this.logoutbutton);
            this.billdetailsDashboardPanel.Controls.Add(this.Addcutomerbutton);
            this.billdetailsDashboardPanel.Controls.Add(this.SalesButton);
            this.billdetailsDashboardPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.billdetailsDashboardPanel.Location = new System.Drawing.Point(0, 0);
            this.billdetailsDashboardPanel.Name = "billdetailsDashboardPanel";
            this.billdetailsDashboardPanel.Size = new System.Drawing.Size(177, 697);
            this.billdetailsDashboardPanel.TabIndex = 1;
            // 
            // MngBIll
            // 
            this.MngBIll.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MngBIll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.MngBIll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MngBIll.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MngBIll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.MngBIll.Location = new System.Drawing.Point(12, 176);
            this.MngBIll.Name = "MngBIll";
            this.MngBIll.Size = new System.Drawing.Size(150, 47);
            this.MngBIll.TabIndex = 3;
            this.MngBIll.Text = "Manage Bill";
            this.MngBIll.UseVisualStyleBackColor = true;
            this.MngBIll.Click += new System.EventHandler(this.MngBIll_Click);
            // 
            // logoutbutton
            // 
            this.logoutbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.logoutbutton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.logoutbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.logoutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutbutton.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutbutton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logoutbutton.Location = new System.Drawing.Point(12, 631);
            this.logoutbutton.Name = "logoutbutton";
            this.logoutbutton.Size = new System.Drawing.Size(150, 40);
            this.logoutbutton.TabIndex = 2;
            this.logoutbutton.Text = "Logout";
            this.logoutbutton.UseVisualStyleBackColor = true;
            this.logoutbutton.Click += new System.EventHandler(this.logoutbutton_Click);
            // 
            // Addcutomerbutton
            // 
            this.Addcutomerbutton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Addcutomerbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.Addcutomerbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addcutomerbutton.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addcutomerbutton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Addcutomerbutton.Location = new System.Drawing.Point(12, 107);
            this.Addcutomerbutton.Name = "Addcutomerbutton";
            this.Addcutomerbutton.Size = new System.Drawing.Size(150, 47);
            this.Addcutomerbutton.TabIndex = 1;
            this.Addcutomerbutton.Text = "Add Club Member";
            this.Addcutomerbutton.UseVisualStyleBackColor = true;
            this.Addcutomerbutton.Click += new System.EventHandler(this.Addcutomerbutton_Click);
            // 
            // SalesButton
            // 
            this.SalesButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.SalesButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.SalesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SalesButton.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.SalesButton.Location = new System.Drawing.Point(12, 36);
            this.SalesButton.Name = "SalesButton";
            this.SalesButton.Size = new System.Drawing.Size(150, 47);
            this.SalesButton.TabIndex = 0;
            this.SalesButton.Text = "Sale Products";
            this.SalesButton.UseVisualStyleBackColor = true;
            this.SalesButton.Click += new System.EventHandler(this.SalesButton_Click);
            // 
            // billdetailsadmindashboarlogo
            // 
            this.billdetailsadmindashboarlogo.BackColor = System.Drawing.Color.Transparent;
            this.billdetailsadmindashboarlogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.billdetailsadmindashboarlogo.Image = global::SuperShopMainV1._00.Properties.Resources.shoplogo1;
            this.billdetailsadmindashboarlogo.Location = new System.Drawing.Point(177, 0);
            this.billdetailsadmindashboarlogo.Name = "billdetailsadmindashboarlogo";
            this.billdetailsadmindashboarlogo.Size = new System.Drawing.Size(675, 105);
            this.billdetailsadmindashboarlogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.billdetailsadmindashboarlogo.TabIndex = 4;
            this.billdetailsadmindashboarlogo.TabStop = false;
            this.billdetailsadmindashboarlogo.UseWaitCursor = true;
            // 
            // billdetailsiid
            // 
            this.billdetailsiid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.billdetailsiid.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.billdetailsiid.Controls.Add(this.searchbill);
            this.billdetailsiid.Controls.Add(this.billdetailtlabel);
            this.billdetailsiid.Controls.Add(this.billdetailsidtexbox);
            this.billdetailsiid.Location = new System.Drawing.Point(183, 111);
            this.billdetailsiid.Name = "billdetailsiid";
            this.billdetailsiid.Size = new System.Drawing.Size(657, 112);
            this.billdetailsiid.TabIndex = 5;
            // 
            // searchbill
            // 
            this.searchbill.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.searchbill.BackColor = System.Drawing.Color.PaleTurquoise;
            this.searchbill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.searchbill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.searchbill.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.searchbill.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchbill.ForeColor = System.Drawing.Color.Black;
            this.searchbill.Location = new System.Drawing.Point(498, 21);
            this.searchbill.Name = "searchbill";
            this.searchbill.Size = new System.Drawing.Size(130, 48);
            this.searchbill.TabIndex = 17;
            this.searchbill.Text = "Search Bill";
            this.searchbill.UseVisualStyleBackColor = false;
            this.searchbill.Click += new System.EventHandler(this.searchbill_Click);
            // 
            // billdetailtlabel
            // 
            this.billdetailtlabel.AutoSize = true;
            this.billdetailtlabel.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.billdetailtlabel.Location = new System.Drawing.Point(11, 26);
            this.billdetailtlabel.Name = "billdetailtlabel";
            this.billdetailtlabel.Size = new System.Drawing.Size(48, 17);
            this.billdetailtlabel.TabIndex = 2;
            this.billdetailtlabel.Text = "Bill ID:";
            // 
            // billdetailsidtexbox
            // 
            this.billdetailsidtexbox.Location = new System.Drawing.Point(123, 24);
            this.billdetailsidtexbox.Name = "billdetailsidtexbox";
            this.billdetailsidtexbox.Size = new System.Drawing.Size(274, 20);
            this.billdetailsidtexbox.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.No;
            this.dataGridView1.Location = new System.Drawing.Point(183, 245);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(657, 426);
            this.dataGridView1.TabIndex = 6;
            // 
            // BillDetailsDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SuperShopMainV1._00.Properties.Resources.background1;
            this.ClientSize = new System.Drawing.Size(852, 697);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.billdetailsiid);
            this.Controls.Add(this.billdetailsadmindashboarlogo);
            this.Controls.Add(this.billdetailsDashboardPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(868, 736);
            this.Name = "BillDetailsDashboard";
            this.Text = "Bill Details Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.billdetailsDashboardPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.billdetailsadmindashboarlogo)).EndInit();
            this.billdetailsiid.ResumeLayout(false);
            this.billdetailsiid.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel billdetailsDashboardPanel;
        private System.Windows.Forms.Button MngBIll;
        private System.Windows.Forms.Button logoutbutton;
        private System.Windows.Forms.Button Addcutomerbutton;
        private System.Windows.Forms.Button SalesButton;
        private System.Windows.Forms.PictureBox billdetailsadmindashboarlogo;
        private System.Windows.Forms.Panel billdetailsiid;
        private System.Windows.Forms.Button searchbill;
        private System.Windows.Forms.Label billdetailtlabel;
        private System.Windows.Forms.TextBox billdetailsidtexbox;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}