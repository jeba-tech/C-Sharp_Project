﻿namespace SuperShopMainV1._00
{
    partial class ClubCustomerDashborad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClubCustomerDashborad));
            this.ClubDashboardPanel = new System.Windows.Forms.Panel();
            this.MngBIll = new System.Windows.Forms.Button();
            this.logoutbutton = new System.Windows.Forms.Button();
            this.Addcutomerbutton = new System.Windows.Forms.Button();
            this.SalesButton = new System.Windows.Forms.Button();
            this.clubdashboardpicbox = new System.Windows.Forms.PictureBox();
            this.ClubCustomerDashboarplanel1 = new System.Windows.Forms.Panel();
            this.refreshclubmemberbtn = new System.Windows.Forms.Button();
            this.Address = new System.Windows.Forms.Label();
            this.clubcustomeraddress = new System.Windows.Forms.TextBox();
            this.Phone = new System.Windows.Forms.Label();
            this.PhneTextClub = new System.Windows.Forms.TextBox();
            this.addedbutton = new System.Windows.Forms.Button();
            this.CustomerEmailLabel = new System.Windows.Forms.Label();
            this.CustomerEmailTextbox = new System.Windows.Forms.TextBox();
            this.datelabel = new System.Windows.Forms.Label();
            this.CustomrNameSalesDashboar = new System.Windows.Forms.Label();
            this.SalesData = new System.Windows.Forms.DateTimePicker();
            this.CustomerNameTextboxSales = new System.Windows.Forms.TextBox();
            this.clubcustomerdatagrid = new System.Windows.Forms.DataGridView();
            this.ClubDashboardPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clubdashboardpicbox)).BeginInit();
            this.ClubCustomerDashboarplanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clubcustomerdatagrid)).BeginInit();
            this.SuspendLayout();
            // 
            // ClubDashboardPanel
            // 
            this.ClubDashboardPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(42)))), ((int)(((byte)(16)))));
            this.ClubDashboardPanel.Controls.Add(this.MngBIll);
            this.ClubDashboardPanel.Controls.Add(this.logoutbutton);
            this.ClubDashboardPanel.Controls.Add(this.Addcutomerbutton);
            this.ClubDashboardPanel.Controls.Add(this.SalesButton);
            this.ClubDashboardPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.ClubDashboardPanel.Location = new System.Drawing.Point(0, 0);
            this.ClubDashboardPanel.Name = "ClubDashboardPanel";
            this.ClubDashboardPanel.Size = new System.Drawing.Size(177, 697);
            this.ClubDashboardPanel.TabIndex = 1;
            // 
            // MngBIll
            // 
            this.MngBIll.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.MngBIll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.MngBIll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MngBIll.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MngBIll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.MngBIll.Location = new System.Drawing.Point(12, 161);
            this.MngBIll.Name = "MngBIll";
            this.MngBIll.Size = new System.Drawing.Size(150, 47);
            this.MngBIll.TabIndex = 4;
            this.MngBIll.Text = "Manage Bill";
            this.MngBIll.UseVisualStyleBackColor = true;
            this.MngBIll.Click += new System.EventHandler(this.MngBIll_Click);
            // 
            // logoutbutton
            // 
            this.logoutbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.logoutbutton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.logoutbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.logoutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutbutton.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutbutton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logoutbutton.Location = new System.Drawing.Point(12, 614);
            this.logoutbutton.Name = "logoutbutton";
            this.logoutbutton.Size = new System.Drawing.Size(150, 40);
            this.logoutbutton.TabIndex = 2;
            this.logoutbutton.Text = "Logout";
            this.logoutbutton.UseVisualStyleBackColor = true;
            this.logoutbutton.Click += new System.EventHandler(this.logoutbutton_Click);
            // 
            // Addcutomerbutton
            // 
            this.Addcutomerbutton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Addcutomerbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.Addcutomerbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addcutomerbutton.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addcutomerbutton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Addcutomerbutton.Location = new System.Drawing.Point(12, 94);
            this.Addcutomerbutton.Name = "Addcutomerbutton";
            this.Addcutomerbutton.Size = new System.Drawing.Size(150, 47);
            this.Addcutomerbutton.TabIndex = 1;
            this.Addcutomerbutton.Text = "Add Club Member";
            this.Addcutomerbutton.UseVisualStyleBackColor = true;
            this.Addcutomerbutton.Click += new System.EventHandler(this.Addcutomerbutton_Click);
            // 
            // SalesButton
            // 
            this.SalesButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.SalesButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.SalesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SalesButton.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.SalesButton.Location = new System.Drawing.Point(12, 32);
            this.SalesButton.Name = "SalesButton";
            this.SalesButton.Size = new System.Drawing.Size(150, 47);
            this.SalesButton.TabIndex = 0;
            this.SalesButton.Text = "Sale Products";
            this.SalesButton.UseVisualStyleBackColor = true;
            this.SalesButton.Click += new System.EventHandler(this.SalesButton_Click);
            // 
            // clubdashboardpicbox
            // 
            this.clubdashboardpicbox.BackColor = System.Drawing.Color.Transparent;
            this.clubdashboardpicbox.Dock = System.Windows.Forms.DockStyle.Top;
            this.clubdashboardpicbox.Image = global::SuperShopMainV1._00.Properties.Resources.shoplogo1;
            this.clubdashboardpicbox.Location = new System.Drawing.Point(177, 0);
            this.clubdashboardpicbox.Name = "clubdashboardpicbox";
            this.clubdashboardpicbox.Size = new System.Drawing.Size(675, 105);
            this.clubdashboardpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.clubdashboardpicbox.TabIndex = 2;
            this.clubdashboardpicbox.TabStop = false;
            this.clubdashboardpicbox.UseWaitCursor = true;
            // 
            // ClubCustomerDashboarplanel1
            // 
            this.ClubCustomerDashboarplanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ClubCustomerDashboarplanel1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ClubCustomerDashboarplanel1.Controls.Add(this.refreshclubmemberbtn);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.Address);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.clubcustomeraddress);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.Phone);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.PhneTextClub);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.addedbutton);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.CustomerEmailLabel);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.CustomerEmailTextbox);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.datelabel);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.CustomrNameSalesDashboar);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.SalesData);
            this.ClubCustomerDashboarplanel1.Controls.Add(this.CustomerNameTextboxSales);
            this.ClubCustomerDashboarplanel1.Location = new System.Drawing.Point(183, 111);
            this.ClubCustomerDashboarplanel1.Name = "ClubCustomerDashboarplanel1";
            this.ClubCustomerDashboarplanel1.Size = new System.Drawing.Size(657, 182);
            this.ClubCustomerDashboarplanel1.TabIndex = 3;
            this.ClubCustomerDashboarplanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.ClubCustomerDashboarplanel1_Paint);
            // 
            // refreshclubmemberbtn
            // 
            this.refreshclubmemberbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.refreshclubmemberbtn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.refreshclubmemberbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.refreshclubmemberbtn.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshclubmemberbtn.ForeColor = System.Drawing.Color.Black;
            this.refreshclubmemberbtn.Location = new System.Drawing.Point(484, 70);
            this.refreshclubmemberbtn.Name = "refreshclubmemberbtn";
            this.refreshclubmemberbtn.Size = new System.Drawing.Size(163, 30);
            this.refreshclubmemberbtn.TabIndex = 23;
            this.refreshclubmemberbtn.Text = "REFRESH";
            this.refreshclubmemberbtn.UseVisualStyleBackColor = false;
            this.refreshclubmemberbtn.Click += new System.EventHandler(this.refreshclubmemberbtn_Click);
            // 
            // Address
            // 
            this.Address.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Address.AutoSize = true;
            this.Address.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address.Location = new System.Drawing.Point(11, 108);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(59, 15);
            this.Address.TabIndex = 22;
            this.Address.Text = "Address:";
            // 
            // clubcustomeraddress
            // 
            this.clubcustomeraddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.clubcustomeraddress.Location = new System.Drawing.Point(123, 106);
            this.clubcustomeraddress.Name = "clubcustomeraddress";
            this.clubcustomeraddress.Size = new System.Drawing.Size(274, 20);
            this.clubcustomeraddress.TabIndex = 21;
            // 
            // Phone
            // 
            this.Phone.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Phone.AutoSize = true;
            this.Phone.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone.Location = new System.Drawing.Point(11, 78);
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(49, 15);
            this.Phone.TabIndex = 20;
            this.Phone.Text = "Phone:";
            // 
            // PhneTextClub
            // 
            this.PhneTextClub.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PhneTextClub.Location = new System.Drawing.Point(123, 76);
            this.PhneTextClub.Name = "PhneTextClub";
            this.PhneTextClub.Size = new System.Drawing.Size(274, 20);
            this.PhneTextClub.TabIndex = 19;
            // 
            // addedbutton
            // 
            this.addedbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.addedbutton.BackColor = System.Drawing.Color.PaleTurquoise;
            this.addedbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addedbutton.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addedbutton.ForeColor = System.Drawing.Color.Black;
            this.addedbutton.Location = new System.Drawing.Point(526, 127);
            this.addedbutton.Name = "addedbutton";
            this.addedbutton.Size = new System.Drawing.Size(75, 23);
            this.addedbutton.TabIndex = 17;
            this.addedbutton.Text = "ADD";
            this.addedbutton.UseVisualStyleBackColor = false;
            this.addedbutton.Click += new System.EventHandler(this.addedbutton_Click);
            // 
            // CustomerEmailLabel
            // 
            this.CustomerEmailLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CustomerEmailLabel.AutoSize = true;
            this.CustomerEmailLabel.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerEmailLabel.Location = new System.Drawing.Point(11, 52);
            this.CustomerEmailLabel.Name = "CustomerEmailLabel";
            this.CustomerEmailLabel.Size = new System.Drawing.Size(41, 15);
            this.CustomerEmailLabel.TabIndex = 14;
            this.CustomerEmailLabel.Text = "Email:";
            // 
            // CustomerEmailTextbox
            // 
            this.CustomerEmailTextbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CustomerEmailTextbox.Location = new System.Drawing.Point(123, 50);
            this.CustomerEmailTextbox.Name = "CustomerEmailTextbox";
            this.CustomerEmailTextbox.Size = new System.Drawing.Size(274, 20);
            this.CustomerEmailTextbox.TabIndex = 13;
            // 
            // datelabel
            // 
            this.datelabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.datelabel.AutoSize = true;
            this.datelabel.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datelabel.Location = new System.Drawing.Point(481, 24);
            this.datelabel.Name = "datelabel";
            this.datelabel.Size = new System.Drawing.Size(40, 17);
            this.datelabel.TabIndex = 7;
            this.datelabel.Text = "Date:";
            // 
            // CustomrNameSalesDashboar
            // 
            this.CustomrNameSalesDashboar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CustomrNameSalesDashboar.AutoSize = true;
            this.CustomrNameSalesDashboar.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomrNameSalesDashboar.Location = new System.Drawing.Point(11, 26);
            this.CustomrNameSalesDashboar.Name = "CustomrNameSalesDashboar";
            this.CustomrNameSalesDashboar.Size = new System.Drawing.Size(106, 15);
            this.CustomrNameSalesDashboar.TabIndex = 2;
            this.CustomrNameSalesDashboar.Text = "Customer Name:";
            // 
            // SalesData
            // 
            this.SalesData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SalesData.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.SalesData.Location = new System.Drawing.Point(526, 21);
            this.SalesData.Name = "SalesData";
            this.SalesData.Size = new System.Drawing.Size(121, 20);
            this.SalesData.TabIndex = 1;
            // 
            // CustomerNameTextboxSales
            // 
            this.CustomerNameTextboxSales.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CustomerNameTextboxSales.Location = new System.Drawing.Point(123, 24);
            this.CustomerNameTextboxSales.Name = "CustomerNameTextboxSales";
            this.CustomerNameTextboxSales.Size = new System.Drawing.Size(274, 20);
            this.CustomerNameTextboxSales.TabIndex = 0;
            // 
            // clubcustomerdatagrid
            // 
            this.clubcustomerdatagrid.AllowUserToAddRows = false;
            this.clubcustomerdatagrid.AllowUserToDeleteRows = false;
            this.clubcustomerdatagrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.clubcustomerdatagrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.clubcustomerdatagrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.clubcustomerdatagrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.clubcustomerdatagrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.clubcustomerdatagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.clubcustomerdatagrid.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.clubcustomerdatagrid.Location = new System.Drawing.Point(183, 299);
            this.clubcustomerdatagrid.Name = "clubcustomerdatagrid";
            this.clubcustomerdatagrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.clubcustomerdatagrid.Size = new System.Drawing.Size(657, 369);
            this.clubcustomerdatagrid.TabIndex = 4;
            // 
            // ClubCustomerDashborad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SuperShopMainV1._00.Properties.Resources.background1;
            this.ClientSize = new System.Drawing.Size(852, 697);
            this.Controls.Add(this.clubcustomerdatagrid);
            this.Controls.Add(this.ClubCustomerDashboarplanel1);
            this.Controls.Add(this.clubdashboardpicbox);
            this.Controls.Add(this.ClubDashboardPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(868, 736);
            this.Name = "ClubCustomerDashborad";
            this.Text = "Club Customer Dashborad";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ClubDashboardPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.clubdashboardpicbox)).EndInit();
            this.ClubCustomerDashboarplanel1.ResumeLayout(false);
            this.ClubCustomerDashboarplanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clubcustomerdatagrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ClubDashboardPanel;
        private System.Windows.Forms.Button logoutbutton;
        private System.Windows.Forms.Button Addcutomerbutton;
        private System.Windows.Forms.Button SalesButton;
        private System.Windows.Forms.PictureBox clubdashboardpicbox;
        private System.Windows.Forms.Panel ClubCustomerDashboarplanel1;
        private System.Windows.Forms.Label Phone;
        private System.Windows.Forms.TextBox PhneTextClub;
        private System.Windows.Forms.Button addedbutton;
        private System.Windows.Forms.Label CustomerEmailLabel;
        private System.Windows.Forms.TextBox CustomerEmailTextbox;
        private System.Windows.Forms.Label datelabel;
        private System.Windows.Forms.Label CustomrNameSalesDashboar;
        private System.Windows.Forms.DateTimePicker SalesData;
        private System.Windows.Forms.TextBox CustomerNameTextboxSales;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.TextBox clubcustomeraddress;
        private System.Windows.Forms.DataGridView clubcustomerdatagrid;
        private System.Windows.Forms.Button refreshclubmemberbtn;
        private System.Windows.Forms.Button MngBIll;
    }
}